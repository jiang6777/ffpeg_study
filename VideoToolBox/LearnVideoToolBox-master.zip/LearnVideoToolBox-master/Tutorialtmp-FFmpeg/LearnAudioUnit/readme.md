因为大小的原因，FFmpeg的库不上传到库中。
需要FFmpeg-iOS库的可用链接
https://share.weiyun.com/86c776660ebd21ea03a69d2a6f51afed

vy6 加 vjy （6个字母，拼一下）

文件夹放在LearnAudioUnit下面，与GL文件夹同级
