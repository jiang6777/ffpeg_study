//
//  WTPlayView.h
//  VideoToolBoxDecodeH264
//
//  Created by ocean on 2018/8/22.
//  Copyright © 2018年 AnDong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WTPlayView : UIView

-(void)showWityPixelBuffer:(CVPixelBufferRef)pixelBuffer;

@end
